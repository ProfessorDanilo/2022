f1,f2 = 1,1
while f2<1000:
    print(f2)
    f1,f2 = f2,f1+f2
